package br.edu.ifal.riolargo.pweb2.Banco.modelo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Conta {
	private static final String True = null;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private double saldo;
	
	private String numero;
	
	@OneToOne( mappedBy="contas", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<transacao> transacoes = new ArrayList<>();
	
	@ManyToMany( mappedBy="contas")	
	private List<Cliente> clientes = new ArrayList<>();

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public double getSaldo() {
		
		return saldo;
	}

	public void setSaldo(double saldo) {
		
		this.saldo = saldo;
	}

	public String getNumero() {
		
		return numero;
	}

	public void setNumero(String numero) {
		
		this.numero = numero;
	}
	
	

}
